# xadmin_bugfix

基于原版xadmin修改，修复原版已知bug，适配Python3.X+Django2.1/2.0
